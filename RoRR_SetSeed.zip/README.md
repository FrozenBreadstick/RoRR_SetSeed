# Seeding Features:
## Seeded successfully thus far:
- Chance Shrines
- Chests
- Equipment Barrels
- XP Barrels
- Boss Drops
- Stage Progression
- Stage Variant
- Chest/Shop/Shrine Spawns
- Boss Spawn

## Not Seeded Successfully yet:
- First Stage
- Enemies Dropping Items

## Things not planned to be seeded:
- Enemy Spawns 

# To Do:
- Menu for setting seed (If you want to change the seed currently, edit the "local seed" variable at the top of the main.lua file in the mod folder)

### THIS MOD IMPLEMENTS CUSTOM SEED LOGIC DUE TO DIFFICULTIES, NORMAL RUNS WILL NOT HAVE A CORRESPONDING SEED FROM THIS MOD

---

### Installation Instructions
Install through the Thunderstore client or r2modman [(more detailed instructions here if needed)](https://return-of-modding.github.io/ModdingWiki/Playing/Getting-Started/).  
Join the [Return of Modding server](https://discord.gg/VjS57cszMq) for support.  